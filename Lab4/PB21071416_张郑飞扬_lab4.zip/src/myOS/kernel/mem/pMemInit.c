#include "../../include/myPrintk.h"
#include "../../include/mem.h"
unsigned long pMemStart;  // 可用的内存的起始地址
unsigned long pMemSize;  // 可用的大小
unsigned long pMemHandler;

void memTest(unsigned long start, unsigned long grainSize){
	/*功能：检测算法
		这一个函数对应实验讲解ppt中的第一大功能-内存检测。
		本函数的功能是检测从start开始有多大的内存可用，具体算法参照ppt检测算法的文字描述
	注意点三个：
	1、覆盖写入和读出就是往指针指向的位置写和读，不要想复杂。
	  (至于为什么这种检测内存的方法可行大家要自己想一下)
	2、开始的地址要大于1M，需要做一个if判断。
	3、grainsize不能太小，也要做一个if判断
	*/
	unsigned long addr = start;
    unsigned short data;
    unsigned short *phead, *ptail;
    unsigned short test1 = 0xAA55;
    unsigned short test2 = 0x55AA;
	int sign = 0; // 检测失败标志
	pMemSize = 0;
	pMemStart = start;

	if (start < 0x100000)
		start = 0x100000;
	if (grainSize < 2)
		grainSize = 2;

    while (!sign) {
        sign = 0;

        phead = (unsigned short *)addr; // grain的头2个字节
        ptail = (unsigned short *)(addr + grainSize - 2); // grain的尾2个字节

        data = *phead; 	// 读出grain的头2个字节
        *phead = test1; // 覆盖写入0xAA55
        if (*phead != test1)
            sign = 1;
        *phead = test2; // 覆盖写入0x55AA
        if (*phead != test2)
            sign = 1;
        *phead = data; // 写回原来的值

        data = *ptail; // 读出grain的尾2个字节
        *ptail = test1; // 覆盖写入0xAA55
        if (*ptail != test1)
            sign = 1;
        *ptail = test2; // 覆盖写入0x55AA
        if (*ptail != test2)
            sign = 1;
        *ptail = data; // 写回原来的值

        if (!sign) {
            addr += grainSize;
            pMemSize += grainSize;
        }
    }
	myPrintk(0x7,"MemStart: %x  \n", pMemStart);
	myPrintk(0x7,"MemSize:  %x  \n", pMemSize);
	
}

extern unsigned long _end;
void pMemInit(void){
	unsigned long _end_addr = (unsigned long) &_end;
	memTest(0x100000,0x1000);
	myPrintk(0x7,"_end:  %x  \n", _end_addr);
	if (pMemStart <= _end_addr) {
		pMemSize -= _end_addr - pMemStart;
		pMemStart = _end_addr;
	}
	
	// 此处选择不同的内存管理算法
	pMemHandler = dPartitionInit(pMemStart,pMemSize);	
}
