#ifndef __I8253_H__
#define __I8253_H__

void init8253(void);

#endif