/*
 * 本文件实现vga的相关功能，清屏和屏幕输出
 * clear_screen和append2screen必须按照如下借口实现
 * 可以增加其他函数供clear_screen和append2screen调用
 */
extern void outb (unsigned short int port_to, unsigned char value);
extern unsigned char inb(unsigned short int port_from);
//VGA字符界面规格：25行80列
//VGA显存初始地址为0xB8000

short cur_line=0;
short cur_column=0;//当前光标位置
#define vga_init_p 0xB8000


void update_cursor(void){
    //通过当前行值cur_cline与列值cur_column回写光标
	// update high 8 bit
	outb(0x3D4, 0x0E);
	outb(0x3D5, ((cur_line * 80 + cur_column) >> 8) & 0xFF);
	// update low 8 bit
	outb(0x3D4, 0x0F);
	outb(0x3D5, (cur_line * 80 + cur_column) & 0xFF);
}

short get_cursor_position(void){
    //获得当前光标，计算出cur_line和cur_column的值
	unsigned int high_8bit, low_8bit, pos;
	outb(0x3D4, 0X0E);
	high_8bit = inb(0x3D5);
	outb(0x3D4, 0x0F);
	low_8bit = inb(0x3D5);
	pos = (high_8bit << 8) + low_8bit;
	cur_line = pos / 80;
	cur_column = pos % 80;
}


void clear_screen(void) {
	int *p;
    	int i = 0;
    	while (i < 0x1000) {
        // fill the screen with spaces (black background)
        p = (int*)(vga_init_p + i);
        *p = 0x0F200F20;   
        i += 4;
    }
    cur_line = cur_column = 0;
    update_cursor();
}

void roll_screen(void){
	//将下一行的字符复制到上行，并将最后一行清空。
	int *pread, *pwrite;  //pread用于读取下一行的内容，pwrite用于写入该行。
    int i = 0;
    while (i < (cur_line * 80 + cur_column)) {
        pwrite = (int*)(vga_init_p + i * 2);
        if (i < (cur_line * 80 + cur_column - 80)) {
            // copy the data from the next line
            pread = (int*)(vga_init_p + i * 2 + 160);
            *(pwrite) = *(pread);
        }
        else
            // clear the last line
            *(pwrite) = 0x0F200F20;
        i += 2;
    }
    cur_line--;
    update_cursor();
}

void put_singlechar(unsigned char c, int color) {
    // judge when to roll the screen
    while (cur_line >= 25)
        roll_screen();
    // putchar
    unsigned char *p;
    p = (unsigned char*)(vga_init_p + (cur_line * 80 + cur_column) * 2);
    *p = c;
    p = (unsigned char*)(vga_init_p + (cur_line * 80 + cur_column) * 2 + 1);
    *p = (unsigned char)color;
    
    if(cur_column == 80){
    		cur_line ++;
    		cur_column = 0;
    }
    else cur_column ++;
    
    update_cursor();
}

void append2screen(char *str,int color){ 
    for (int i = 0; str[i] != '\0'; i++) {
        switch (str[i]) {
		    case '\n':
			//换行    
            cur_line ++;
			cur_column = 0;
			update_cursor();
            while (cur_line >= 25)
                roll_screen();
            break;
                 
            default:
            	put_singlechar(str[i], color);
            break;
        }
    } 
}


