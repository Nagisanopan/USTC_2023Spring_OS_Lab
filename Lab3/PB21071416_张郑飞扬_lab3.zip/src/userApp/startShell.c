#include "vga.h"
#include "uart.h"
#include "string.h"
#include "myPrintk.h"


typedef struct _command {
    char name[80];
    char help_content[200];
    int (*func)(int argc, char *argv[]);
} myCommand;

int func_help(int argc, char *argv[]);
int func_cmd(int argc, char *argv[]);

myCommand cmds[] = {
    { "cmd", "cmd : List all command\n\0", func_cmd },
    { "help", "Usage: help [command]\n\0Display info about[command]\n\0", func_help },
    { "NULL", "NULL", 0 }
};

typedef struct _param {
    int argc;
    char *argv[8];
} param;

int devide_string(const char *str,char **str_devided) {
//分割字符串（去空格）函数，参数为待分割字符串，分隔好的字符串数组。返回值为分割字符串个数
    int devidednum = 0;
    int i = 0;

    while (*str++ == ' '); 
    str--;

    while (*str) {
        if (*str == ' ') {
            while (*str++ == ' '); 
            if (*--str) { 
                str_devided[devidednum++][i] = '\0';
                i = 0;
            }
        }
        else
            str_devided[devidednum][i++] = *str++;
    } 
    str_devided[devidednum++][i] = '\0';

    return devidednum;
}


int search_cmd(int argc, char *argv[]) {

    if (!myStrlen(argv[0])) //无效输入
        return 1;

    for (int i = 0; myStrcmp(cmds[i].name, "NULL") != 0; i++) {
        if (!myStrcmp(argv[0], cmds[i].name)) {
            cmds[i].func(argc, argv); //调用对应命令函数
            return 0;
        }
    }

    myPrintk(0x7, "The cmd is not defined\n");
    return 1;
}

int func_help(int argc, char *argv[]) {

    if (argc == 1) {
        myPrintk(0x2, "Usage: help [command]\nDisplay info about[command]\n");
        return 1;
    }

    for (int i = 0; myStrcmp(cmds[i].name , "NULL") != 0; i++) {
        if (!myStrcmp(argv[1], cmds[i].name)) {
            myPrintk(0x2, "%s", cmds[i].help_content);
            return 1;
        }
    }
    
    myPrintk(0x7, "The cmd is not defined\n");
    return 0;
}


int func_cmd(int argc, char *argv[]) {

    for (int i = 0; myStrcmp(cmds[i].name , "NULL") != 0; i++)
        myPrintk(0x2, "%s\n", cmds[i].name);

    return 0;
}


void get_input_cmd(char *buf) {

    char *str = buf;
    unsigned char input;

    while ((input = uart_get_char()) != '\r') {
    handle_input:
        if (input == '\r')
            break;

        else {
            *str++ = input;
            myPrintk(0x7, "%c", input); //回显
            uart_put_char(input);
        }
    }
    *str = '\0';

    myPrintk(0x7, " -pseudo_terminal\0");
    myPrintk(0x7, "\n"); 
    uart_put_chars("\r\n");
}


void startShell(void) {

    char buf[256]; 
    char cmd_params[8][8]; 
    param cmd; 
    for (int i = 0; i < 8; i++)
        cmd.argv[i] = cmd_params[i]; 

    while (1) {

        myPrintk(0x7, "Student>>");

        get_input_cmd(buf);

        cmd.argc = devide_string(buf, cmd.argv);
        
        search_cmd(cmd.argc, cmd.argv);
    }

    return;
}
