#include "io.h"
#include "myPrintk.h"
#include "uart.h"
#include "vga.h"

void startShell(void);

void myMain(void){    
    startShell();
    return;
}
