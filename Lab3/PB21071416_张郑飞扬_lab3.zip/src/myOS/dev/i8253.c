#include "io.h"
#define HZ_I8253 1193180
#define HZ_INTERRUPT 100

void init8253(void){
	short para = HZ_I8253 / HZ_INTERRUPT; //分频参数
	outb(0x43, 0x34);	
	outb(0x40, (unsigned char)para); 	//低八位
	outb(0x40, (unsigned char)(para >> 8)); //高八位

	outb(0x21, inb(0x21) & 0xFE); //允许时钟中断
}
