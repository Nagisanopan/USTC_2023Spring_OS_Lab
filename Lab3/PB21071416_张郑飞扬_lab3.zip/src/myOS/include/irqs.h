#ifndef __I386_IRQS_H__
#define __I386_IRQS_H__

#include "myPrintk.h" 
void enableInterrupt(void);
void disableInterrupt(void);
void ignoreIntBody(void);

#endif
