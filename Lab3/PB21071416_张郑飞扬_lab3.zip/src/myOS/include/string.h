#ifndef __STRING_H__
#define  __STRING_H__

int myStrcmp(const char *str1, const char *str2);
int myStrlen(const char *str);
int myStrnlen(const char *str, int maxlen);

#endif
