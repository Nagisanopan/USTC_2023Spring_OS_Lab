#ifndef __I8253_H__
#define __I8253_H__

#include "io.h"
void init8253(void);

#endif
