#ifndef __I8259A_H__
#define __I8259A_H__

#include "io.h"
void init8259A(void);

#endif
