#define TICK_HOOK_VOL 10 //Hook表容量

int system_ticks = 0;

int hook_func_num = 0;
void (*hook_list[TICK_HOOK_VOL])(void); // Hook函数指针表

void setWallClockHook(void (*func)(void)) {
    hook_list[hook_func_num++] = func;
}	//钩子函数，用来“挂钩”

void tick(void) {

    system_ticks++;

    // 调用所有挂钩函数
    for (int i = 0; i < hook_func_num; i++)
    	hook_list[i]();
}
