#ifndef __TIMER_H__
#define __TIMER_H__

void init_timer(void);
unsigned int get_current_time(void);

#endif
