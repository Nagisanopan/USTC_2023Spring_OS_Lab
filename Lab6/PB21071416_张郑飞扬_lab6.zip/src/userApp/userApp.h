#ifndef __USER_APP_H__
#define __USER_APP_H__

// user should define this, don't include the init task
#define FCFS_TASK_NUM 4
#define PRIO_TASK_NUM 6
#define RR_TASK_NUM 6
#define SJF_TASK_NUM 7

#endif
